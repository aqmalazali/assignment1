<?php
//products route
require __DIR__ . '/Controllers/employee.php';
