<?php
use Slim\Http\Request; //namespace
use Slim\Http\Response; //namespace

//include gamelist.php file
include __DIR__. '/../Controllers/function/employeeProc.php';
//read table games
$app->get('/employee', function (Request $request, Response $response, array
$arg){
return $this->response->withJson(array('data' => 'success'), 200);
});
// read all data from table employee
$app->get('/allemployee',function (Request $request, Response $response,array $arg)
{
$data = getAllemployee($this->db);
if (is_null($data)) {
return $this->response->withHeader('Access-Control-Allow-Origin', '*')->withJson(array('error' => 'no data'), 404);
}
return $this->response->withJson(array('data' => $data), 200);
});
//request table webapi by condition (employee id)
$app->get('/employee/[{EmpCode}]', function ($request, $response, $args){
$employeeId = $args['EmpCode'];
if (!is_numeric($employeeId)) {
return $this->response->withJson(array('error' => 'numeric paremeter required'), 500);
}
$data = getemployee($this->db,$employeeId);
if (empty($data)) {
return $this->response->withJson(array('error' => 'no data'), 500);
}
return $this->response->withJson(array('data' => $data), 200);
});

//post method
$app->post('/employee/add', function ($request, $response, $args) {
    $form_data = $request->getParsedBody();
    $data = createemployee($this->db, $form_data);
    if ($data <= 0) {
    return $this->response->withJson(array('error' => 'add data fail'), 500);
    }
    return $this->response->withJson(array('add data' => 'success'), 200);
    }
    );

//delete
$app->delete('/employee/del/[{EmpCode}]', function ($request, $response, $args){
    $EmpCode = $args['EmpCode'];
    if (!is_numeric($EmpCode)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $data = deleteemployee($this->db,$EmpCode);
    if (empty($data)) {
    return $this->response->withJson(array($EmpCode=> 'is successfully deleted'), 202);};
    });
    
    //put table products
    $app->put('/employee/put/[{EmpCode}]', function ($request, $response, $args){$EmpCode = $args['EmpCode'];

    if (!is_numeric($EmpCode)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $form_dat=$request->getParsedBody();
    $data=updateemployee($this->db,$form_dat,$EmpCode);
    if ($data <=0)
    return $this->response->withJson(array('data' => 'successfully updated'), 200);
});