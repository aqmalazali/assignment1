<?php
//get all employee
function getAllemployee($db)
{
$sql = 'Select p.EmpCode, p.EmpFName, p.Job, p.Salary  from employee p ';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//get employee by id
function getemployee($db, $employeeId)
{
$sql = 'Select p.EmpCode, p.EmpFName, p.Job, p.Salary  from employee p  ';
$sql .= 'Where p.EmpCode = :EmpCode';
$stmt = $db->prepare ($sql);
$id = (int) $employeeId;
$stmt->bindParam(':EmpCode', $id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//post method
function createemployee($db, $form_data) {
    $sql = 'Insert into employee ( EmpFName, Job, Salary ) ';
    $sql .= 'values (:EmpFName, :Job, :Salary )';
    $stmt = $db->prepare ($sql);
    $stmt->bindParam(':EmpFName', $form_data['EmpFName']);
    $stmt->bindParam(':Job', $form_data['Job']);
    $stmt->bindParam(':Salary', $form_data['Salary']);
    $stmt->execute();
    return $db->lastInsertID();//insert last number.. continue
    }

//delete employee by id
function deleteemployee($db,$EmpCode) {
    $sql = ' Delete from employee where EmpCode = :EmpCode';
    $stmt = $db->prepare($sql);
    $id = (int)$EmpCode;
    $stmt->bindParam(':EmpCode', $EmpCode, PDO::PARAM_INT);
    $stmt->execute();
    }
    //update employee by id
    function updateemployee($db,$form_dat,$EmpCode) {
    $sql = 'UPDATE employee SET EmpFName = :EmpFName , Job = :Job , Salary = :Salary ';
    $sql .=' WHERE EmpCode = :EmpCode';
    $stmt = $db->prepare ($sql);
    $id = (int)$EmpCode;
    $stmt->bindParam(':EmpCode', $EmpCode, PDO::PARAM_INT);
    $stmt->bindParam(':EmpFName', $form_dat['EmpFName']);
    $stmt->bindParam(':Job', $form_dat['Job']);
    $stmt->bindParam(':Salary', ($form_dat['Salary']));
    $stmt->execute();
    }